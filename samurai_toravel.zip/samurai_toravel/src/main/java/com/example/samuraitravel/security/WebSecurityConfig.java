package com.example.samuraitravel.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

//1. クラスに各種アノテーションをつける

@Configuration
@EnableWebSecurity
@EnableMethodSecurity

public class WebSecurityConfig {
	
//	2.メソッドに@Beanアノテーションをつける
//	メソッドの戻り値（インスタンス）がDIコンテナに登録されるようになります
    @Bean
    
//   3.誰に、どのページへのアクセスを許可するかを設定する
//    securityFilterChain()メソッド内ではまず、authorizeHttpRequests()メソッドで誰に、どのページへのアクセスを許可するかを設定します。
//    1.requestMatchers("ルートパス").permitAll()：すべてのユーザーにアクセスを許可するURLを設定する
//    2.requestMatchers("ルートパス").hasRole("ロール名")：指定したロールにのみアクセスを許可するURLを設定する
//    3.anyRequest().authenticated()：他のURLはログインを必要とする（ロールは問わない）
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests((requests) -> requests                
                .requestMatchers("/css/**", "/images/**", "/js/**", "/storage/**", "/", "/signup/**", "/houses", "/houses/{id}", "/stripe/webhook").permitAll()  // すべてのユーザーにアクセスを許可するURL
                .anyRequest().authenticated()                   // 上記以外のURLはログインが必要（会員または管理者のどちらでもOK）
            )
            
//            4. ログイン・ログアウトに関するURLを設定する
//            以下5点を抑える
//            	1.loginPage("ルートパス")：ログインページのURLを設定する
//            	2.loginProcessingUrl("ルートパス")：ログインフォームの送信先URLを設定する
//            	3.defaultSuccessUrl("ルートパス")：ログイン成功時のリダイレクト先URLを設定する
//            	4.failureUrl("ルートパス")：ログイン失敗時のリダイレクト先URLを設定する
//            	5.logoutSuccessUrl("ルートパス")：ログアウト時のリダイレクト先URLを設定する
            .formLogin((form) -> form
                .loginPage("/login")              // ログインページのURL
                .loginProcessingUrl("/login")     // ログインフォームの送信先URL
                .defaultSuccessUrl("/?loggedIn")  // ログイン成功時のリダイレクト先URL
                .failureUrl("/login?error")       // ログイン失敗時のリダイレクト先URL
                .permitAll()
            )
            .logout((logout) -> logout
                .logoutSuccessUrl("/?loggedOut")  // ログアウト時のリダイレクト先URL
                .permitAll()
            )
            .csrf().ignoringRequestMatchers("/stripe/webhook");

            
        return http.build();
    }
    
//    5. パスワードのハッシュアルゴリズムを設定する
//    passwordEncoder()メソッドでは、
//    BCryptPasswordEncoderクラスのインスタンスを返すことで、
//    パスワードのハッシュアルゴリズム（ハッシュ化のルール）を「BCrypt」に設定

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    


}
