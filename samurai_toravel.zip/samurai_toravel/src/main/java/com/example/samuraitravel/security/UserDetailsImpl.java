package com.example.samuraitravel.security;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.samuraitravel.entity.User;

//1. UserDetailsインターフェースを実装する
//	implementsキーワードを使ってUserDetailsインターフェースを実装します。
public class UserDetailsImpl implements UserDetails {
    private final User user;
    private final Collection<GrantedAuthority> authorities;
    
    public UserDetailsImpl(User user, Collection<GrantedAuthority> authorities) {
        this.user = user;
        this.authorities = authorities;
    }
    
    public User getUser() {
        return user;
    }
    
//    2.@Overrideアノテーションでメソッドを上書きする
//    UserDetailsインターフェースを実装したので、
//    UserDetailsインターフェースに定義されている抽象メソッドを上書きし、
//    具体的な処理内容を作成しなければなりません
    
    // ハッシュ化済みのパスワードを返す
    @Override
    public String getPassword() {
        return user.getPassword();
    }
    
    // ログイン時に利用するユーザー名（メールアドレス）を返す
    @Override
    public String getUsername() {
        return user.getEmail();
    }
    
//    *getAuthorities()メソッドでは戻り値の型に<? extends A>という見慣れない書き方をしていますが、
//    これは「Aまたはそのサブタイプすべて」という意味です。
    
    // ロールのコレクションを返す
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }
    
    // アカウントが期限切れでなければtrueを返す
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }
    
    // ユーザーがロックされていなければtrueを返す
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }    
    
    // ユーザーのパスワードが期限切れでなければtrueを返す
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
    
//    3. isEnabled()メソッドでユーザーの有効性をチェックする
//    ユーザーの有効性チェックは必要です。
//    そこで、isEnabled()メソッドだけはuser.getEnabled()でenabledフィールドの値を返すようにしています。

    
    // ユーザーが有効であればtrueを返す
    @Override
    public boolean isEnabled() {
        return user.getEnabled();
    }

}
