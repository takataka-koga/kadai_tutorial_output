package com.example.samuraitravel.event;

import org.springframework.context.ApplicationEvent;

import com.example.samuraitravel.entity.User;

import lombok.Getter;

/*
 * 1. ApplicationEventクラスを継承する
 *  ApplicationEventクラスはイベントを作成するための基本的なクラスで、イベントのソース（発生源）などを保持
 * 2. イベントに関する情報を保持する
 *  員登録したユーザーの情報（Userオブジェクト）とリクエストを受けたURL（https://ドメイン名/signup）を保持
 * 3. クラスに@Getterアノテーションをつける
 *  Lombokが提供する@Getterアノテーションをクラスにつけることで、ゲッターのみが自動的に定義される
 *
 */
@Getter
public class SignupEvent extends ApplicationEvent {
    private User user;
    private String requestUrl;        

    public SignupEvent(Object source, User user, String requestUrl) {
        super(source);
        
        this.user = user;        
        this.requestUrl = requestUrl;
    }

    
}
